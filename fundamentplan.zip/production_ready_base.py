"""
Fundament-Generator für Fasssaunen - Production Ready
Basis-Code für Claude Code Weiterentwicklung

NOCH ZU IMPLEMENTIEREN:
- SaunaModelConfig (SQLAlchemy Model)
- DatabaseManager
- SaunaService (mit Config-Handling)
- tkinter GUI
- CSV-Import
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime


# ============================================================================
# ENUMS
# ============================================================================

class Orientation(Enum):
    """Ausrichtung von Maßketten"""
    HORIZONTAL = 'horizontal'
    VERTICAL = 'vertical'


class TextAlignment(Enum):
    """Textausrichtung bei Maßketten"""
    ABOVE = 'above'
    BELOW = 'below'
    LEFT = 'left'
    RIGHT = 'right'


# ============================================================================
# LAYOUT CONFIGURATION
# ============================================================================

@dataclass
class LayoutConfig:
    """Konfiguration für alle Abstände und Positionen"""
    
    # Diagrammgrenzen - symmetrisch
    xlim_left: float = -40
    xlim_right_offset: float = 62.4
    ylim_bottom: float = -60
    ylim_top_offset: float = 175
    
    # Headline-Position
    headline_y_offset: float = 15
    
    # Legend-Position (vier Zeilen unter Headline)
    legend_x: float = -35
    legend_y: float = 53
    legend_line_spacing: float = 12
    legend_box_text_gap: float = 5
    
    # LINKE SEITE: Zwei Kategorien mit äußerem und innerem Abstand
    mass_links_aussen_abstand: float = -26.325
    mass_links_innen_abstand: float = -14.175
    
    # RECHTE SEITE: Zwei Kategorien mit innerem und äußerem Abstand
    mass_rechts_innen_abstand: float = 14.175
    mass_rechts_aussen_abstand: float = 26.325
    
    # Unten: X-Breite
    mass_unten_abstand: float = 20


# ============================================================================
# DTOs - CONTENT ELEMENTS
# ============================================================================

@dataclass
class ContentElement:
    """Basis-DTO für alle Content-Elemente mit Position und Größe"""
    x_start: float
    y_start: float
    x_end: float
    y_end: float
    
    @property
    def breite(self) -> float:
        return self.x_end - self.x_start
    
    @property
    def hoehe(self) -> float:
        return self.y_end - self.y_start
    
    @property
    def x_mitte(self) -> float:
        return (self.x_start + self.x_end) / 2
    
    @property
    def y_mitte(self) -> float:
        return (self.y_start + self.y_end) / 2


@dataclass
class Fundament(ContentElement):
    """DTO für Fundament-Streifen"""
    edgecolor: str = 'darkgray'
    facecolor: str = 'lightgray'
    alpha: float = 0.6


@dataclass
class Saunafuss(ContentElement):
    """DTO für Saunafüße"""
    nummer: Optional[int] = None
    edgecolor: str = 'black'
    facecolor: str = 'saddlebrown'
    alpha: float = 0.8


@dataclass
class Arbeitsbereich(ContentElement):
    """DTO für Arbeitsbereich"""
    edgecolor: str = 'red'
    linewidth: float = 2
    hatch_spacing: float = 3
    alpha: float = 0.8


# ============================================================================
# MEASURE OBJECTS
# ============================================================================

@dataclass
class AbstractMeasure(ABC):
    """Basis-Klasse für Maßketten"""
    
    start: float
    end: float
    label: str
    orientation: Orientation
    text_alignment: TextAlignment
    fontsize: float = 8
    pfeil_breite: float = 1.5
    hilfs_alpha: float = 0.5
    farbe: str = 'black'


@dataclass
class FundamentMeasure(AbstractMeasure):
    """Maßkette für Fundament-Breiten"""
    farbe: str = 'darkgreen'


@dataclass
class FussMeasure(AbstractMeasure):
    """Maßkette für Fuß-Dicken"""
    farbe: str = 'darkred'


@dataclass
class InnenabstandMeasure(AbstractMeasure):
    """Maßkette für Innenabstände"""
    farbe: str = 'red'


@dataclass
class AussenmassMeasure(AbstractMeasure):
    """Maßkette für Außenmaße"""
    farbe: str = 'blue'


@dataclass
class BreiteMeasure(AbstractMeasure):
    """Maßkette für X-Breite"""
    farbe: str = 'purple'
    fontsize: float = 11


@dataclass
class ArbeitsbereichMeasure(AbstractMeasure):
    """Maßkette für Arbeitsbereich-Höhe"""
    farbe: str = 'red'
    fontsize: float = 10


# ============================================================================
# LEGEND OBJECTS
# ============================================================================

@dataclass
class LegendItem:
    """Ein einzelnes Legendenelement mit Farbe und Text"""
    
    box_color: str
    text: str
    box_width: float = 15
    box_height: float = 8
    fontsize: float = 9


class Legend:
    """Klasse für die Legende mit konfigurierbarer Position"""
    
    def __init__(self, ax, x_start: float, y_start: float, 
                 line_spacing: float = 12, box_text_gap: float = 5):
        """
        Args:
            ax: Matplotlib Axes Objekt
            x_start: X-Position der Legende (linksbündig)
            y_start: Y-Position der Legende (erste Zeile)
            line_spacing: Abstand zwischen den Zeilen
            box_text_gap: Abstand zwischen Box und Text
        """
        self.ax = ax
        self.x_start = x_start
        self.y_start = y_start
        self.line_spacing = line_spacing
        self.box_text_gap = box_text_gap
        self.items: List[LegendItem] = []
    
    def add_item(self, item: LegendItem) -> None:
        """Fügt ein Legendenelement hinzu"""
        self.items.append(item)
    
    def zeichne(self) -> None:
        """Zeichnet alle Legendenelemente"""
        for i, item in enumerate(self.items):
            y = self.y_start - (i * self.line_spacing)
            
            # Farb-Box zeichnen
            rect = plt.Rectangle(
                (self.x_start, y - item.box_height / 2),
                item.box_width, item.box_height,
                linewidth=1,
                edgecolor='black',
                facecolor=item.box_color,
                alpha=0.8
            )
            self.ax.add_patch(rect)
            
            # Text zeichnen
            text_x = self.x_start + item.box_width + self.box_text_gap
            self.ax.text(
                text_x, y,
                item.text,
                fontsize=item.fontsize,
                ha='left', va='center'
            )


# ============================================================================
# FACTORY
# ============================================================================

class ContentElementFactory:
    """Factory zur Erzeugung von Content-Elementen"""
    
    @staticmethod
    def create_fundament(x_start: float, x_end: float, y_start: float, y_end: float) -> Fundament:
        """Erstellt ein Fundament-Element"""
        return Fundament(
            x_start=x_start, y_start=y_start,
            x_end=x_end, y_end=y_end
        )
    
    @staticmethod
    def create_saunafuss(x_start: float, x_end: float, y_start: float, y_end: float,
                        nummer: int) -> Saunafuss:
        """Erstellt ein Saunafuss-Element"""
        return Saunafuss(
            x_start=x_start, y_start=y_start,
            x_end=x_end, y_end=y_end,
            nummer=nummer
        )
    
    @staticmethod
    def create_arbeitsbereich(x_start: float, x_end: float, y_start: float, hoehe: float) -> Arbeitsbereich:
        """Erstellt ein Arbeitsbereich-Element"""
        return Arbeitsbereich(
            x_start=x_start, y_start=y_start,
            x_end=x_end, y_end=y_start + hoehe
        )


# ============================================================================
# FUNDAMENT PLAN GENERATOR - REFAKTORIERT
# ============================================================================

class FundamentPlan:
    """Übergeordnete Klasse für die Generierung aller Content-Elemente"""
    
    def __init__(self, breite_cm: float, layout_config: LayoutConfig = None,
                 fuss_breite: float = 8, fundament_breite: float = 20):
        """
        Args:
            breite_cm: Breite der Sauna
            layout_config: LayoutConfig für Positionen und Abstände
            fuss_breite: Breite eines Fußes (cm)
            fundament_breite: Breite eines Fundaments (cm)
        """
        self.breite_cm = breite_cm
        self.layout_config = layout_config or LayoutConfig()
        self.fuss_breite = fuss_breite
        self.fundament_breite = fundament_breite
        
        self.fundamente: List[Fundament] = []
        self.saunafuesse: List[Saunafuss] = []
        self.arbeitsbereich: Optional[Arbeitsbereich] = None
        self.massnahmen: List[AbstractMeasure] = []
        
        self.factory = ContentElementFactory()
    
    def berechne_positionen(self, innenabstaende_str: str) -> None:
        """
        Berechnet alle Positionen basierend auf Innenabständen und erzeugt CE's
        
        Args:
            innenabstaende_str: Komma-getrennte Liste von Abständen (z.B. "96,96")
        """
        # Berechne Fuss-Positionen
        fuss_positionen = self._berechne_fuss_positionen(innenabstaende_str)
        
        # Erstelle Saunafuesse
        for i, (y_start, y_end) in enumerate(fuss_positionen):
            fuss = self.factory.create_saunafuss(
                x_start=0, x_end=self.breite_cm,
                y_start=y_start, y_end=y_end,
                nummer=i + 1
            )
            self.saunafuesse.append(fuss)
        
        # Berechne und erstelle Fundamente
        fundament_positionen = self._berechne_fundament_positionen(fuss_positionen)
        for y_mitte, y_start, y_end in fundament_positionen:
            fundament = self.factory.create_fundament(
                x_start=0, x_end=self.breite_cm,
                y_start=y_start, y_end=y_end
            )
            self.fundamente.append(fundament)
        
        # Erstelle Arbeitsbereich
        arbeitsbereich_start = fundament_positionen[-1][2]
        self.arbeitsbereich = self.factory.create_arbeitsbereich(
            x_start=0, x_end=self.breite_cm,
            y_start=arbeitsbereich_start, hoehe=75
        )
        
        # Erstelle Maßketten
        self._erstelle_massnahmen(fuss_positionen, fundament_positionen)
    
    def _berechne_fuss_positionen(self, innenabstaende_str: str) -> List[tuple]:
        """Berechnet Fußpositionen"""
        if not innenabstaende_str:
            return [(0, self.fuss_breite)]
        
        abstaende = [float(x.strip()) for x in str(innenabstaende_str).split(',')]
        fuss_positionen = []
        y_current = 0
        
        fuss_positionen.append((y_current, y_current + self.fuss_breite))
        
        for abstand in abstaende:
            y_current = fuss_positionen[-1][1] + abstand
            fuss_positionen.append((y_current, y_current + self.fuss_breite))
        
        return fuss_positionen
    
    def _berechne_fundament_positionen(self, fuss_positionen: List[tuple]) -> List[tuple]:
        """Berechnet Fundament-Positionen"""
        fundament_positionen = []
        
        for y_start, y_end in fuss_positionen:
            y_mitte = (y_start + y_end) / 2
            fund_y_start = y_mitte - self.fundament_breite / 2
            fund_y_end = y_mitte + self.fundament_breite / 2
            fundament_positionen.append((y_mitte, fund_y_start, fund_y_end))
        
        return fundament_positionen
    
    def _erstelle_massnahmen(self, fuss_positionen: List[tuple], 
                             fundament_positionen: List[tuple]) -> None:
        """Erstellt alle Maßketten"""
        
        # Fundament-Breiten (links)
        for y_mitte, y_start, y_end in fundament_positionen:
            breite = y_end - y_start
            messung = FundamentMeasure(
                start=y_start, end=y_end,
                label=f'{breite:.0f}',
                orientation=Orientation.VERTICAL,
                text_alignment=TextAlignment.RIGHT
            )
            self.massnahmen.append(messung)
        
        # Fuß-Dicken (links)
        for y_start, y_end in fuss_positionen:
            messung = FussMeasure(
                start=y_start, end=y_end,
                label=f'{self.fuss_breite}',
                orientation=Orientation.VERTICAL,
                text_alignment=TextAlignment.RIGHT
            )
            self.massnahmen.append(messung)
        
        # Innenabstände (rechts)
        for i in range(len(fuss_positionen) - 1):
            y_end_1 = fuss_positionen[i][1]
            y_start_2 = fuss_positionen[i+1][0]
            abstand = y_start_2 - y_end_1
            
            messung = InnenabstandMeasure(
                start=y_end_1, end=y_start_2,
                label=f'{abstand:.0f}',
                orientation=Orientation.VERTICAL,
                text_alignment=TextAlignment.LEFT
            )
            self.massnahmen.append(messung)
        
        # Außenmaß (rechts)
        y_start_first = fundament_positionen[0][1]
        y_end_last = fundament_positionen[-1][2]
        messung = AussenmassMeasure(
            start=y_start_first, end=y_end_last,
            label=f'{y_end_last - y_start_first:.0f}cm',
            orientation=Orientation.VERTICAL,
            text_alignment=TextAlignment.LEFT,
            fontsize=12
        )
        self.massnahmen.append(messung)
        
        # Arbeitsbereich-Höhe (rechts)
        arbeitsbereich_start = fundament_positionen[-1][2]
        messung = ArbeitsbereichMeasure(
            start=arbeitsbereich_start, end=arbeitsbereich_start + 75,
            label='75',
            orientation=Orientation.VERTICAL,
            text_alignment=TextAlignment.LEFT
        )
        self.massnahmen.append(messung)
        
        # X-Breite (unten)
        messung = BreiteMeasure(
            start=0, end=self.breite_cm,
            label=f'{self.breite_cm:.0f}',
            orientation=Orientation.HORIZONTAL,
            text_alignment=TextAlignment.BELOW
        )
        self.massnahmen.append(messung)
    
    def get_all_elements(self) -> List[ContentElement]:
        """Gibt alle Content-Elemente zurück"""
        elements = []
        elements.extend(self.fundamente)
        elements.extend(self.saunafuesse)
        if self.arbeitsbereich:
            elements.append(self.arbeitsbereich)
        return elements


# ============================================================================
# DRAW SERVICE
# ============================================================================

class DrawService:
    """Service zum Zeichnen von Content-Elementen"""
    
    def __init__(self, ax):
        """
        Args:
            ax: Matplotlib Axes Objekt
        """
        self.ax = ax
    
    def draw_fundament(self, fundament: Fundament) -> None:
        """Zeichnet ein Fundament"""
        rect = plt.Rectangle(
            (fundament.x_start, fundament.y_start),
            fundament.breite, fundament.hoehe,
            linewidth=2,
            edgecolor=fundament.edgecolor,
            facecolor=fundament.facecolor,
            alpha=fundament.alpha
        )
        self.ax.add_patch(rect)
    
    def draw_saunafuss(self, fuss: Saunafuss) -> None:
        """Zeichnet einen Saunafuss"""
        rect = plt.Rectangle(
            (fuss.x_start, fuss.y_start),
            fuss.breite, fuss.hoehe,
            linewidth=2,
            edgecolor=fuss.edgecolor,
            facecolor=fuss.facecolor,
            alpha=fuss.alpha
        )
        self.ax.add_patch(rect)
        
        if fuss.nummer is not None:
            self.ax.text(
                fuss.x_mitte, fuss.y_mitte,
                f'Fuß {fuss.nummer}',
                ha='center', va='center',
                fontsize=9, color='white', fontweight='bold'
            )
    
    def draw_arbeitsbereich(self, arbeitsbereich: Arbeitsbereich) -> None:
        """Zeichnet einen Arbeitsbereich"""
        rect = plt.Rectangle(
            (arbeitsbereich.x_start, arbeitsbereich.y_start),
            arbeitsbereich.breite, arbeitsbereich.hoehe,
            linewidth=arbeitsbereich.linewidth,
            edgecolor=arbeitsbereich.edgecolor,
            facecolor='none',
            alpha=arbeitsbereich.alpha,
            linestyle='-'
        )
        self.ax.add_patch(rect)
        
        # Schraffur
        for y_hatch in np.arange(arbeitsbereich.y_start, arbeitsbereich.y_end, 
                                 arbeitsbereich.hatch_spacing):
            self.ax.plot(
                [arbeitsbereich.x_start, arbeitsbereich.x_end],
                [y_hatch, y_hatch],
                'r-', linewidth=0.5, alpha=0.4
            )
    
    def draw_elements(self, elements: List[ContentElement]) -> None:
        """Zeichnet alle Elemente"""
        for element in elements:
            if isinstance(element, Fundament):
                self.draw_fundament(element)
            elif isinstance(element, Saunafuss):
                self.draw_saunafuss(element)
            elif isinstance(element, Arbeitsbereich):
                self.draw_arbeitsbereich(element)


# ============================================================================
# MEASURE SERVICE
# ============================================================================

class MeasureService:
    """Service zum Zeichnen von Maßketten"""
    
    # Konstante für Abstand Beschriftung zu Maßlinie
    TEXT_OFFSET = 2.5  # cm
    
    def __init__(self, ax):
        """
        Args:
            ax: Matplotlib Axes Objekt
        """
        self.ax = ax
    
    def draw_measure(self, measure: AbstractMeasure, position: float) -> None:
        """
        Zeichnet eine Maßkette basierend auf AbstractMeasure Objekt
        
        Args:
            measure: AbstractMeasure Objekt mit allen Properties
            position: X oder Y Position der Maßkette (je nach Orientation)
        """
        if measure.orientation == Orientation.VERTICAL:
            self._draw_vertical(measure, position)
        else:
            self._draw_horizontal(measure, position)
    
    def _draw_vertical(self, measure: AbstractMeasure, x_position: float) -> None:
        """Zeichnet eine vertikale Maßkette"""
        y_start = measure.start
        y_end = measure.end
        
        # Hilfslinien
        self.ax.plot([0, x_position], [y_start, y_start], 'k--',
                    linewidth=0.8, alpha=measure.hilfs_alpha)
        self.ax.plot([0, x_position], [y_end, y_end], 'k--',
                    linewidth=0.8, alpha=measure.hilfs_alpha)
        
        # Pfeil
        self.ax.annotate(
            '', xy=(x_position, y_start),
            xytext=(x_position, y_end),
            arrowprops=dict(arrowstyle='<->', color=measure.farbe,
                           lw=measure.pfeil_breite)
        )
        
        # Text
        y_mitte = (y_start + y_end) / 2
        
        if measure.text_alignment == TextAlignment.RIGHT:
            text_x = x_position - self.TEXT_OFFSET
            ha = 'right'
        else:  # LEFT
            text_x = x_position + self.TEXT_OFFSET
            ha = 'left'
        
        self.ax.text(
            text_x, y_mitte, str(measure.label),
            fontsize=measure.fontsize, color=measure.farbe,
            fontweight='bold', ha=ha, va='center',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                     alpha=0.8, edgecolor='none')
        )
    
    def _draw_horizontal(self, measure: AbstractMeasure, y_position: float) -> None:
        """Zeichnet eine horizontale Maßkette"""
        x_start = measure.start
        x_end = measure.end
        
        # Hilfslinien
        self.ax.plot([x_start, x_start], [0, y_position], 'k--',
                    linewidth=0.8, alpha=measure.hilfs_alpha)
        self.ax.plot([x_end, x_end], [0, y_position], 'k--',
                    linewidth=0.8, alpha=measure.hilfs_alpha)
        
        # Pfeil
        self.ax.annotate(
            '', xy=(x_start, y_position - self.TEXT_OFFSET),
            xytext=(x_end, y_position - self.TEXT_OFFSET),
            arrowprops=dict(arrowstyle='<->', color=measure.farbe,
                           lw=measure.pfeil_breite)
        )
        
        # Text
        x_mitte = (x_start + x_end) / 2
        
        if measure.text_alignment == TextAlignment.BELOW:
            text_y = y_position - self.TEXT_OFFSET - 3
            va = 'top'
        else:  # ABOVE
            text_y = y_position + self.TEXT_OFFSET + 3
            va = 'bottom'
        
        self.ax.text(
            x_mitte, text_y, str(measure.label),
            fontsize=measure.fontsize, color=measure.farbe,
            fontweight='bold', ha='center', va=va,
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                     alpha=0.8, edgecolor='none')
        )


# ============================================================================
# DIAGRAM
# ============================================================================

class Diagramm:
    """Klasse für die Gesamte Zeichnung"""
    
    def __init__(self, fundament_plan: FundamentPlan, title: str = ''):
        """
        Args:
            fundament_plan: FundamentPlan Objekt
            title: Titel des Diagramms
        """
        self.fundament_plan = fundament_plan
        self.title = title
        self.layout = fundament_plan.layout_config
        
        y_max = max([f.y_end for f in fundament_plan.fundamente]) + self.layout.ylim_top_offset if fundament_plan.fundamente else 100
        
        self.fig, self.ax = plt.subplots(figsize=(16, 10))
        self._setup_axes(fundament_plan.breite_cm, y_max)
        
        self.draw_service = DrawService(self.ax)
        self.measure_service = MeasureService(self.ax)
    
    def _setup_axes(self, breite_cm: float, hoehe_cm: float) -> None:
        """Konfiguriert die Achsen"""
        self.ax.set_xlim(self.layout.xlim_left, breite_cm + self.layout.xlim_right_offset)
        self.ax.set_ylim(self.layout.ylim_bottom, hoehe_cm)
        self.ax.set_aspect('equal')
        self.ax.grid(True, alpha=0.3)
        
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        self.ax.set_xticklabels([])
        self.ax.set_yticklabels([])
        self.ax.set_xlabel('')
        self.ax.set_ylabel('')
    
    def zeichne(self) -> None:
        """Zeichnet alle Elemente und Maßketten"""
        # Headline oben im Diagramm platzieren
        breite = self.fundament_plan.breite_cm
        y_max = max([f.y_end for f in self.fundament_plan.fundamente]) + self.layout.ylim_top_offset if self.fundament_plan.fundamente else 100
        
        headline_y = y_max - self.layout.headline_y_offset
        self.ax.text(
            breite / 2, headline_y,
            f'{self.title} - Draufsicht',
            fontsize=14, fontweight='bold',
            ha='center', va='center'
        )
        
        # Legende erstellen und zeichnen
        legend = Legend(
            self.ax,
            x_start=self.layout.legend_x,
            y_start=y_max - self.layout.legend_y,
            line_spacing=self.layout.legend_line_spacing,
            box_text_gap=self.layout.legend_box_text_gap
        )
        
        legend.add_item(LegendItem(
            box_color='lightgray',
            text='Streifenfundament frostsichere Tiefe 80cm'
        ))
        legend.add_item(LegendItem(
            box_color='saddlebrown',
            text='Saunafuß'
        ))
        legend.add_item(LegendItem(
            box_color='red',
            text='Arbeitsbereich Monteur/Elektriker',
            box_height=8
        ))
        
        legend.zeichne()
        
        # Zeichne alle Content-Elemente
        elements = self.fundament_plan.get_all_elements()
        self.draw_service.draw_elements(elements)
        
        # Maßlinien-Positionen aus LayoutConfig
        
        # Linke Seite: zwei Kategorien
        pos_links_aussen = self.layout.mass_links_aussen_abstand
        pos_links_innen = self.layout.mass_links_innen_abstand
        
        # Rechte Seite: zwei Kategorien
        pos_rechts_innen = breite + self.layout.mass_rechts_innen_abstand
        pos_rechts_aussen = breite + self.layout.mass_rechts_aussen_abstand
        
        # Unten
        pos_unten = self.fundament_plan.fundamente[0].y_start - self.layout.mass_unten_abstand if self.fundament_plan.fundamente else 0
        
        # Zeichne Maßketten
        for measure in self.fundament_plan.massnahmen:
            if isinstance(measure, FundamentMeasure):
                self.measure_service.draw_measure(measure, pos_links_aussen)
            elif isinstance(measure, FussMeasure):
                self.measure_service.draw_measure(measure, pos_links_innen)
            elif isinstance(measure, InnenabstandMeasure):
                self.measure_service.draw_measure(measure, pos_rechts_innen)
            elif isinstance(measure, AussenmassMeasure):
                self.measure_service.draw_measure(measure, pos_rechts_aussen)
            elif isinstance(measure, ArbeitsbereichMeasure):
                self.measure_service.draw_measure(measure, pos_rechts_aussen)
            elif isinstance(measure, BreiteMeasure):
                self.measure_service.draw_measure(measure, pos_unten)
    
    def speichern(self, filename: str, dpi: int = 150) -> None:
        """Speichert das Diagramm"""
        plt.tight_layout()
        plt.savefig(filename, dpi=dpi, bbox_inches='tight')
        print(f'✓ Gespeichert: {filename}')
        plt.close()


# ============================================================================
# GENERATOR
# ============================================================================

class FundamentGenerator:
    """Haupt-Generator Klasse"""
    
    def __init__(self, csv_path: str):
        """Initialisiert den Generator"""
        self.modelle = pd.read_csv(csv_path)
    
    def generiere_diagramm(self, model_id: str, innenabstaende_str: str,
                          output_dir: str = '/mnt/user-data/outputs') -> str:
        """Generiert ein komplettes Fundament-Diagramm"""
        
        # Modell-Daten laden
        modell = self.modelle[self.modelle['model_id'] == model_id].iloc[0]
        w_cm = modell['w_cm']
        model_name = modell['model_name']
        
        # FundamentPlan erstellen und Positionen berechnen
        plan = FundamentPlan(breite_cm=w_cm)
        plan.berechne_positionen(innenabstaende_str)
        
        # Diagramm erstellen und zeichnen
        diagramm = Diagramm(plan, model_name)
        diagramm.zeichne()
        
        # Speichern
        os.makedirs(output_dir, exist_ok=True)
        filename = f'{output_dir}/fundament_{model_id}_{innenabstaende_str.replace(",", "_")}.png'
        diagramm.speichern(filename)
        
        return filename


if __name__ == '__main__':
    gen = FundamentGenerator('/mnt/project/fasssauna_modelle.csv')
    
    print("\n" + "="*70)
    print("FUNDAMENT-GENERATOR - Production Ready (vor Config-Refactoring)")
    print("="*70 + "\n")
    
    abstaende_konfiguration = {
        'fass_standard': '96,96',
        'fass_vorraum': '100,100',
        'premium': '150,150',
        'xl': '96,96,96',
        'palkkio': '120,120',
    }
    
    for model_id, abstaende in abstaende_konfiguration.items():
        gen.generiere_diagramm(model_id, abstaende)
    
    print("\n" + "="*70)
    print("Verarbeitung abgeschlossen!")
    print("="*70 + "\n")
