================================================================================
SAUNA FUNDAMENT-GENERATOR - ARCHITEKTUR-REFAKTORIERUNG
================================================================================

PROBLEM: Hardcodierte Werte
├── fuss_breite = 8
├── fundament_breite = 20
├── innenabstaende = "96,96"
└── Diese müssen pro Saunamodell konfigurierbar werden

================================================================================
1. DATENMODELL (Model First Approach)
================================================================================

Entity: SaunaModelConfig
├── model_id: str (Primary Key)           # z.B. "fass_standard"
├── model_name: str                        # z.B. "Fasssauna Standard"
├── width_cm: float                        # Breite aus CSV
│
├── *** GEOMETRIE PARAMETER ***
├── footWidthX: float = 8                  # Fußbreite (X-Achse) in cm
├── footThicknessY: float = 8              # Fußdicke (Y-Achse) in cm
├── foundationWidthY: float = 20           # Fundamentbreite (Y-Achse) in cm
│
├── *** ABSTÄNDE PARAMETER ***
├── innerSpacings: str = "96,96"           # Komma-getrennte Innenabstände
│   └─ Speicherformat: "96,96,96" für 3 Abstände (= 4 Füße)
│
├── workAreaHeight: float = 75             # Arbeitsbereich Höhe
│
├── created_at: datetime
├── updated_at: datetime
└── is_custom: bool = False                # Ob Nutzer es angepasst hat


Entity: SaunaProject
├── project_id: str (Primary Key)
├── model_id: str (Foreign Key → SaunaModelConfig)
├── project_name: str
├── diagram_png_base64: TEXT               # Blob für Vorschau
├── layout_overrides: JSON                 # Optional: Custom LayoutConfig
├── created_at: datetime
├── updated_at: datetime
└── notes: str                             # Notizen des Nutzers


================================================================================
2. DATENBANK-STRATEGIE: Code First mit ORM (SQLAlchemy)
================================================================================

WARUM ORM?
├── ✓ Python-Objekte statt SQL schreiben
├── ✓ Migrations einfach (Alembic)
├── ✓ Type-Safety durch Dataclasses
├── ✓ Validation in Model-Klassen
└── ✓ Relationen automatisch gehandhabt

WARUM NICHT "Model First" (DBSchema zuerst)?
├── ✗ Würde manuell CREATE TABLE schreiben
├── ✗ Python-Code wäre nur Wrapper
├── ✗ Änderungen schwer zu tracken

WARUM NICHT "Database First"?
├── ✗ CSV ist die "Source of Truth" (fasssauna_modelle.csv)
├── ✗ SQLite nur für Custom-Configs und Projekte
└── ✗ Zu komplex für diesen Use-Case


================================================================================
3. FLOW-ARCHITEKTUR
================================================================================

FLOW 1: STAMMDATEN INITIALISIEREN (Einmalig)
┌─────────────────────────────────────────────────────┐
│ 1. CSV laden (fasssauna_modelle.csv)                │
│    └─ model_id, model_name, width_cm                │
│                                                      │
│ 2. SaunaModelConfig erstellen (Standard-Werte)      │
│    └─ footWidthX=8, footThicknessY=8, etc.         │
│                                                      │
│ 3. In SQLite speichern (einmalig)                   │
│    └─ Nutzer kann später überschreiben              │
└─────────────────────────────────────────────────────┘


FLOW 2: KONFIGURATION ANPASSEN (Formular)
┌─────────────────────────────────────────────────────┐
│ Formular-Felder (pro Modell):                        │
│                                                      │
│ ┌─ GEOMETRIE ────────────────────────────────────┐ │
│ │ □ Fußbreite (X):        [8]     cm            │ │
│ │ □ Fußdicke (Y):         [8]     cm            │ │
│ │ □ Fundamentbreite (Y):   [20]    cm           │ │
│ └────────────────────────────────────────────────┘ │
│                                                      │
│ ┌─ ABSTÄNDE ─────────────────────────────────────┐ │
│ │ □ Innenabstände:        [96,96]   cm          │ │
│ │   (1. Abstand, 2. Abstand, 3. Abstand...)     │ │
│ └────────────────────────────────────────────────┘ │
│                                                      │
│ ┌─ SONSTIGES ────────────────────────────────────┐ │
│ │ □ Arbeitsbereich Höhe:   [75]    cm           │ │
│ └────────────────────────────────────────────────┘ │
│                                                      │
│ Button: [Speichern] [Zurücksetzen auf Standard]   │
└─────────────────────────────────────────────────────┘
         ↓
    SaunaModelConfig.update()
         ↓
    DB speichern


FLOW 3: DIAGRAMM GENERIEREN (mit Custom-Config)
┌─────────────────────────────────────────────────────┐
│ 1. SaunaModelConfig laden (mit Custom-Werten)      │
│                                                      │
│ 2. FundamentPlan initialisieren                    │
│    ├── footWidthX = config.footWidthX              │
│    ├── footThicknessY = config.footThicknessY      │
│    ├── foundationWidthY = config.foundationWidthY  │
│    └── innerSpacings = config.innerSpacings        │
│                                                      │
│ 3. Algorithmus ausführen (berechne_positionen)     │
│                                                      │
│ 4. Diagramm zeichnen                               │
│                                                      │
│ 5. SaunaProject speichern (mit Diagramm-Blob)      │
└─────────────────────────────────────────────────────┘


================================================================================
4. CODE-STRUKTUR (Python Desktop-App)
================================================================================

models.py (SQLAlchemy ORM)
├── class SaunaModelConfig(Base):
│   ├── __tablename__ = "sauna_model_configs"
│   ├── model_id: str = Column(String, primary_key=True)
│   ├── model_name: str = Column(String)
│   ├── width_cm: float = Column(Float)
│   ├── footWidthX: float = Column(Float, default=8)
│   ├── footThicknessY: float = Column(Float, default=8)
│   ├── foundationWidthY: float = Column(Float, default=20)
│   ├── innerSpacings: str = Column(String)        # "96,96"
│   ├── workAreaHeight: float = Column(Float, default=75)
│   ├── created_at: datetime = Column(DateTime, default=now())
│   ├── updated_at: datetime = Column(DateTime, onupdate=now())
│   ├── is_custom: bool = Column(Boolean, default=False)
│   │
│   └── Methods:
│       ├── from_csv_row(model_id, model_name, width_cm)
│       ├── get_inner_spacings() -> List[float]
│       ├── set_inner_spacings(spacings: List[float])
│       └── to_dict()
│
└── class SaunaProject(Base):
    ├── __tablename__ = "sauna_projects"
    ├── project_id: str = Column(String, primary_key=True)
    ├── model_id: str = Column(String, ForeignKey("sauna_model_configs.model_id"))
    ├── model: Relationship = relationship("SaunaModelConfig")
    ├── project_name: str = Column(String)
    ├── diagram_png_base64: str = Column(Text)
    ├── layout_overrides: dict = Column(JSON, nullable=True)
    ├── created_at: datetime
    ├── updated_at: datetime
    └── notes: str


database.py (Persistence Layer)
├── class DatabaseManager:
│   ├── __init__(db_path: str)
│   ├── init_db()                      # Erstelle Tabellen
│   ├── import_csv(csv_path: str)      # Lade CSV → DB
│   │
│   └── Methods für SaunaModelConfig:
│       ├── get_model_config(model_id) → SaunaModelConfig
│       ├── get_all_models() → List[SaunaModelConfig]
│       ├── save_model_config(config: SaunaModelConfig)
│       ├── reset_to_default(model_id)
│       └── list_custom_models() → List[SaunaModelConfig]
│
│   └── Methods für SaunaProject:
│       ├── save_project(project: SaunaProject)
│       ├── get_project(project_id)
│       ├── list_projects(model_id=None)
│       └── delete_project(project_id)


fundament_plan.py (Business Logic - REFAKTORIERT)
├── class FundamentPlan:
│   ├── __init__(self, model_config: SaunaModelConfig, layout_config: LayoutConfig)
│   │   ├── self.model_config = model_config  # ← GEÄNDERT!
│   │   └── self.layout_config = layout_config
│   │
│   ├── berechne_positionen(innenabstaende_str: str = None)
│   │   ├── if not innenabstaende_str:
│   │   │   └── innenabstaende_str = self.model_config.innerSpacings
│   │   │
│   │   ├── fuss_positionen = self._berechne_fuss_positionen(
│   │   │       innenabstaende_str,
│   │   │       foot_width=self.model_config.footWidthX,
│   │   │       foot_thickness=self.model_config.footThicknessY
│   │   │   )
│   │   │
│   │   └── fundament_positionen = self._berechne_fundament_positionen(
│   │       fuss_positionen,
│   │       foundation_width=self.model_config.foundationWidthY
│   │   )
│   │
│   └── _berechne_fuss_positionen(...)
│       └── Nutzt jetzt footWidthX/footThicknessY aus config!


service.py (Use Cases)
├── class SaunaService:
│   ├── __init__(db: DatabaseManager)
│   │
│   ├── # CONFIG-VERWALTUNG
│   ├── get_model_config(model_id) → SaunaModelConfig
│   ├── update_model_config(model_id, data: dict) → SaunaModelConfig
│   │   ├── Validierung der Eingaben
│   │   ├── DB speichern
│   │   └── Markiere als is_custom=True
│   │
│   ├── reset_model_config(model_id)
│   │   └── Setze auf Standard-Werte zurück
│   │
│   ├── # DIAGRAMM-GENERIERUNG
│   ├── generate_diagram(model_id, innenabstaende=None) → bytes
│   │   ├── config = self.db.get_model_config(model_id)
│   │   ├── plan = FundamentPlan(config, LayoutConfig())
│   │   ├── plan.berechne_positionen(innenabstaende)
│   │   ├── diagram = Diagramm(plan, ...)
│   │   └── return diagram.to_png_bytes()
│   │
│   └── # PROJEKT-VERWALTUNG
│       ├── save_project(...)
│       └── list_projects()


================================================================================
5. DATENBANK-INITIALISIERUNG
================================================================================

Startup-Sequence:

1. DB öffnen (oder erstellen)
   └─ sauna_fundament.db

2. SQLAlchemy: Alle Tabellen erstellen
   └─ sqlalchemy.create_all()

3. CSV laden
   ├─ Lese fasssauna_modelle.csv
   ├─ Für jede Zeile: SaunaModelConfig(
   │   model_id=...,
   │   model_name=...,
   │   width_cm=...,
   │   footWidthX=8,
   │   footThicknessY=8,
   │   foundationWidthY=20,
   │   innerSpacings="96,96",  # oder abhängig von Modell
   │   workAreaHeight=75,
   │   is_custom=False
   │)
   └─ Speichere in DB (nur wenn noch nicht vorhanden)

4. Fertig!
   └─ Beim nächsten Start: Tabellen existieren, nutze gespeicherte Werte


================================================================================
6. FORMULAR-FLOW (GUI)
================================================================================

┌───────────────────────────────────────────────────────┐
│ MODELL-AUSWAHL DROPDOWN                              │
└─────────────────┬───────────────────────────────────┘
                  │
                  ↓
          ┌───────────────────────────────────────────┐
          │ Button: [Konfigurieren]                   │
          └─────────────┬───────────────────────────┘
                        │
                        ↓
          ┌─────────────────────────────────────────┐
          │ MODAL: Modell-Konfiguration             │
          │                                         │
          │ Fußbreite X:       [8]                  │
          │ Fußdicke Y:        [8]                  │
          │ Fundamentbreite Y: [20]                 │
          │ Innenabstände:     [96,96]              │
          │ Arbeitsbereich:    [75]                 │
          │                                         │
          │ [Speichern] [Zurücksetzen] [Abbrechen] │
          └─────────────┬───────────────────────────┘
                        │
                        ↓
                  service.update_model_config()
                        │
                        ↓
                  DB speichern + is_custom=True


================================================================================
7. VALIDIERUNG & ERROR HANDLING
================================================================================

SaunaModelConfig-Validierung:
├── footWidthX > 0 and footWidthX < 50
├── footThicknessY > 0 and footThicknessY < 50
├── foundationWidthY > 0 and foundationWidthY < 100
├── innerSpacings: Validiere Format "num,num,num..."
│   └─ Alle Werte > 0
└── workAreaHeight > 0 and workAreaHeight < 200

Error Messages:
├── "Fußbreite muss zwischen 1 und 50 cm liegen"
├── "Innenabstände müssen komma-getrennt und positiv sein"
└── "Mindestens 1 Innenabstand erforderlich (für 2 Füße)"


================================================================================
8. MIGRATION / BACKWARDS-COMPATIBILITY
================================================================================

Szenario: Nutzer hat bereits alte HTML-App mit localStorage

Option A: Einfach neu anfangen
└─ SQLite ist separate Datenbank, localStorage bleibt unangetastet

Option B: Migration schreiben
├── localStorage Daten auslesen
├── → SaunaProject-Objekte erzeugen
└── → In SQLite importieren


================================================================================
9. STRUKTUR-ÜBERSICHT (Dateisystem)
================================================================================

sauna_fundament_app/
├── main.py                          # Entry Point
├── requirements.txt                 # Dependencies
│
├── config.py                        # Konfiguration
│
├── models.py                        # SQLAlchemy Models
├── database.py                      # DatabaseManager
├── service.py                       # SaunaService (Business Logic)
│
├── sauna_fundament_generator_clean.py   # Alter Python-Code
├── fundament_plan.py                # REFAKTORIERT mit model_config
├── diagram.py                       # Diagramm-Klasse
│
├── gui/                             # GUI (tkinter oder PyQt)
│   ├── main_window.py
│   ├── config_dialog.py
│   └── project_list_widget.py
│
├── data/
│   ├── fasssauna_modelle.csv
│   └── sauna_fundament.db          # SQLite (Auto-erstellt)
│
└── output/
    └── diagrams/                    # PNG-Exports


================================================================================
10. ABHÄNGIGKEITEN (requirements.txt)
================================================================================

sqlalchemy>=2.0.0          # ORM
alembic>=1.12.0           # Migrations (optional)
pandas>=2.0.0             # CSV-Handling
matplotlib>=3.7.0         # Diagramme
PyQt6>=6.0.0              # GUI (oder tkinter built-in)


================================================================================
ZUSAMMENFASSUNG
================================================================================

✓ CODE FIRST Approach (mit SQLAlchemy ORM)
  └─ Python-Modelle definieren, DB folgt automatisch

✓ Zwei getrennte Datenquellen:
  ├─ CSV: Model-Stammdaten (read-only)
  └─ SQLite: Custom-Configs + Projekte (read-write)

✓ Separation of Concerns:
  ├─ models.py: Datenstrukturen
  ├─ database.py: DB-Zugriff
  ├─ service.py: Business-Logik
  └─ fundament_plan.py: Algorithmen (REFAKTORIERT)

✓ Validierung auf Service-Layer
✓ GUI kann Models direkt nutzen
✓ Einfach zu testen (mocks von DB-Layer)

================================================================================
NÄCHSTE SCHRITTE
================================================================================

1. models.py schreiben (SQLAlchemy Models)
2. database.py schreiben (DatabaseManager)
3. fundament_plan.py refaktorieren (nutze model_config)
4. service.py schreiben (Business Logic)
5. GUI schreiben (tkinter oder PyQt)
6. CSV-Import implementieren
7. Testing

================================================================================
