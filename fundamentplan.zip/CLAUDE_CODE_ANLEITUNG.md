================================================================================
CLAUDE CODE - ÜBERGABE-ANLEITUNG
================================================================================

Lieber Claude Code,

bitte implementiere basierend auf den folgenden Dateien eine produktionsreife
Python-Desktop-App mit SQLite, SQLAlchemy ORM und tkinter GUI.

================================================================================
DATEIEN
================================================================================

1. ARCHITECTURE_PLAN.md
   └─ Detaillierter Plan mit:
      - Datenmodellen (SaunaModelConfig, SaunaProject)
      - Database-Strategie (Code First mit SQLAlchemy)
      - Flow-Architektur
      - Validierung & Error Handling

2. production_ready_base.py
   └─ Kompletter, produktionsreifer Code mit:
      - Alle LayoutConfig, DTOs, Measure-Klassen
      - Legend, Factory, DrawService, MeasureService
      - FundamentPlan (Algorithmen)
      - Diagramm-Klasse
      - FundamentGenerator
      └─ NOCH NICHT IMPLEMENTIERT: SaunaModelConfig, Database, GUI

================================================================================
AUFGABEN (in dieser Reihenfolge)
================================================================================

1. DATENMODELLE (models.py)
   ├── SaunaModelConfig(Base):
   │   ├── model_id: String (Primary Key)
   │   ├── model_name: String
   │   ├── width_cm: Float
   │   ├── footWidthX: Float = 8
   │   ├── footThicknessY: Float = 8
   │   ├── foundationWidthY: Float = 20
   │   ├── innerSpacings: String (komma-getrennt: "96,96")
   │   ├── workAreaHeight: Float = 75
   │   ├── created_at: DateTime
   │   ├── updated_at: DateTime
   │   └── is_custom: Boolean = False
   │
   │   Methods:
   │   ├── from_csv_row(model_id, model_name, width_cm) → SaunaModelConfig
   │   ├── get_inner_spacings() → List[float]
   │   ├── set_inner_spacings(spacings: List[float]) → None
   │   └── to_dict() → dict
   │
   └── SaunaProject(Base):
       ├── project_id: String (Primary Key)
       ├── model_id: String (Foreign Key)
       ├── model: Relationship(SaunaModelConfig)
       ├── project_name: String
       ├── diagram_png_base64: Text
       ├── layout_overrides: JSON
       ├── created_at: DateTime
       ├── updated_at: DateTime
       └── notes: String

2. DATABASE MANAGER (database.py)
   ├── init_db(db_path: str)
   │   └─ Erstelle alle Tabellen
   │
   ├── import_csv(csv_path: str)
   │   └─ Lade fasssauna_modelle.csv → SaunaModelConfig
   │
   ├── # SaunaModelConfig Methods:
   ├── get_model_config(model_id: str) → SaunaModelConfig
   ├── get_all_models() → List[SaunaModelConfig]
   ├── save_model_config(config: SaunaModelConfig) → None
   ├── reset_to_default(model_id: str) → None
   ├── list_custom_models() → List[SaunaModelConfig]
   │
   └── # SaunaProject Methods:
       ├── save_project(project: SaunaProject) → None
       ├── get_project(project_id: str) → SaunaProject
       ├── list_projects(model_id: str = None) → List[SaunaProject]
       └── delete_project(project_id: str) → None

3. SERVICE LAYER (service.py)
   ├── get_model_config(model_id: str) → SaunaModelConfig
   │
   ├── update_model_config(model_id: str, data: dict) → SaunaModelConfig
   │   ├── Validiere alle Eingaben
   │   ├── Setze is_custom = True
   │   ├── Speichere in DB
   │   └── Return aktualisierte Config
   │
   ├── reset_model_config(model_id: str) → None
   │   └─ Setze auf Standard-Werte zurück, is_custom = False
   │
   ├── generate_diagram(model_id: str, innerSpacings: str = None) → bytes (PNG)
   │   ├── Lade SaunaModelConfig
   │   ├── Erstelle FundamentPlan(
   │   │       breite_cm=config.width_cm,
   │   │       fuss_breite=config.footWidthX,
   │   │       fundament_breite=config.foundationWidthY
   │   │   )
   │   ├── plan.berechne_positionen(innerSpacings or config.innerSpacings)
   │   ├── Zeichne Diagramm
   │   └── Return PNG als bytes
   │
   └── # Projekt-Verwaltung:
       ├── save_project(project: SaunaProject) → None
       └── list_projects() → List[SaunaProject]

4. REFAKTORIERE FundamentPlan (in production_ready_base.py)
   ├── Ersetze hardcodierte Werte:
   │   ├── self.fuss_breite = fuss_breite  (default 8)
   │   └── self.fundament_breite = fundament_breite  (default 20)
   │
   ├── In _berechne_fuss_positionen():
   │   └─ Nutze self.fuss_breite statt hardcodiert
   │
   └── In _berechne_fundament_positionen():
       └─ Nutze self.fundament_breite statt hardcodiert

5. GUI (gui/main_window.py) - tkinter
   
   ┌─────────────────────────────────────────────────┐
   │ SAUNA FUNDAMENT-PLAN GENERATOR                  │
   ├─────────────────────────────────────────────────┤
   │                                                  │
   │ [Modell-Auswahl Dropdown] [Konfigurieren]       │
   │                                                  │
   │ ┌──────────────────────────────────────────┐   │
   │ │ KONFIGURATION (Modal)                    │   │
   │ │                                          │   │
   │ │ Fußbreite X (cm):    [8]                 │   │
   │ │ Fußdicke Y (cm):     [8]                 │   │
   │ │ Fundament-Breite Y (cm): [20]           │   │
   │ │ Innenabstände (cm):  [96,96]            │   │
   │ │ Arbeitsbereich (cm): [75]               │   │
   │                                          │   │
   │ │ [Speichern] [Zurücksetzen] [Abbrechen] │   │
   │ └──────────────────────────────────────────┘   │
   │                                                  │
   │ [Diagramm generieren]                           │
   │                                                  │
   │ ┌──────────────────────────────────────────┐   │
   │ │ VORSCHAU (Diagramm)                      │   │
   │ │                                          │   │
   │ │  [Sauna-Diagramm wird hier angezeigt]   │   │
   │ │                                          │   │
   │ └──────────────────────────────────────────┘   │
   │                                                  │
   │ [Download] [Speichern als Projekt]             │
   │                                                  │
   │ Projekte:                                       │
   │ ┌──────────────────────────────────────────┐   │
   │ │ [Projekt 1] [Öffnen] [Löschen] [Download]   │
   │ │ [Projekt 2] [Öffnen] [Löschen] [Download]   │
   │ └──────────────────────────────────────────┘   │
   │                                                  │
   └─────────────────────────────────────────────────┘

6. VALIDIERUNG
   ├── footWidthX: 0 < x < 50
   ├── footThicknessY: 0 < x < 50
   ├── foundationWidthY: 0 < x < 100
   ├── innerSpacings: Format "num,num,..." alle > 0
   └── workAreaHeight: 0 < x < 200

7. STRUKTUR (Dateien die Du erstellen sollst)
   ├── models.py (SQLAlchemy Models)
   ├── database.py (DatabaseManager)
   ├── service.py (SaunaService)
   ├── gui/
   │   └── main_window.py (tkinter GUI)
   ├── main.py (Entry Point)
   ├── config.py (Konfiguration)
   └── requirements.txt

   NUTZE:
   ├── production_ready_base.py (als Basis)
   │   └─ Kopiere alle Klassen rüber und refaktoriere
   └── ARCHITECTURE_PLAN.md (als Referenz)

8. DEPENDENCIES (requirements.txt)
   ├── sqlalchemy>=2.0.0
   ├── pandas>=2.0.0
   ├── matplotlib>=3.7.0
   ├── alembic>=1.12.0 (optional, für Migrations)
   └── # tkinter ist built-in

================================================================================
WICHTIGE ANFORDERUNGEN
================================================================================

✓ Code First Approach (SQLAlchemy Models definieren, DB folgt)
✓ Zwei Datenquellen:
  ├─ CSV (fasssauna_modelle.csv) - read-only Stammdaten
  └─ SQLite (sauna_fundament.db) - Custom-Configs & Projekte
✓ Validierung auf Service-Layer
✓ Alle hartcodierten Werte (fuss_breite, fundament_breite) müssen aus Config kommen
✓ GUI muss Models direkt nutzen können
✓ Fehlerbehandlung mit aussagekräftigen Meldungen
✓ Projekt-Verwaltung (speichern/laden/löschen)

================================================================================
REFERENZEN
================================================================================

1. production_ready_base.py
   └─ Nutze die vorhandenen Klassen:
      ├── LayoutConfig
      ├── ContentElement, Fundament, Saunafuss, Arbeitsbereich
      ├── Measure-Klassen (FundamentMeasure, FussMeasure, etc.)
      ├── Legend, LegendItem
      ├── FundamentPlan (REFAKTORIEREN!)
      ├── DrawService, MeasureService
      └── Diagramm, FundamentGenerator

2. ARCHITECTURE_PLAN.md
   └─ Für detaillierte Anforderungen und Flows

3. CSV-Datei: fasssauna_modelle.csv
   └─ Lade diese beim ersten Start → DB

================================================================================
WORKFLOW
================================================================================

1. User startet App
   └─ Datenbank wird initialisiert
   └─ CSV wird geladen (falls noch nicht geschehen)
   └─ GUI öffnet sich

2. User wählt Modell
   └─ Aktuelle Config wird geladen (oder Default)

3. User klickt "Konfigurieren"
   └─ Modal öffnet sich mit aktuellen Werten
   └─ User bearbeitet Werte
   └─ Click "Speichern"
   └─ SaunaService.update_model_config() wird aufgerufen
   └─ DB wird aktualisiert

4. User klickt "Diagramm generieren"
   └─ SaunaService.generate_diagram() wird aufgerufen
   └─ Diagramm wird in Vorschau angezeigt
   └─ User kann Download oder als Projekt speichern

5. Alle Projekte sind in der Projekt-Liste sichtbar
   └─ User kann laden/löschen/erneut downloaden

================================================================================
FRAGEN/NOTIZEN
================================================================================

- innerSpacings sollte als komma-separierter String in DB gespeichert werden
- get_inner_spacings() gibt List[float] zurück
- set_inner_spacings(List[float]) speichert als String
- is_custom Flag markiert Nutzer-Anpassungen
- workAreaHeight ist aktuell hart auf 75 codiert - auch configurierbar?
- Sollten wir auch foundationDepth (80cm) configurierbar machen?

================================================================================
LIEFERN
================================================================================

✓ Alle Python-Module (.py Dateien)
✓ requirements.txt
✓ Strukturiert und kommentiert
✓ Produktionsreif (Error-Handling, Validierung)
✓ Optional: Kurze README.md mit Nutzungsanleitung

================================================================================
